
import React from "react";
import Navigator from "./Navigator";

const AddressAutoComplete = () => {
  return (
        <Navigator />
  );
};

export default {
  title: "AddressAutoComplete",
  navigator: AddressAutoComplete
};
