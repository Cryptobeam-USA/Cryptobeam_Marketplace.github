from django.apps import AppConfig


class ModulesConfig(AppConfig):
    name = "modules"
    verbose_name = "Crowdbotics Modules"
